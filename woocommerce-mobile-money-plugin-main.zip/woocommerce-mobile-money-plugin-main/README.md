# WooCommerce Mobile Money CI
Woocommerce payment plugin for mobile money payment.

## How it works
- Install the plugin in your woocommer website
- Click on manage to Add your Mobile money numbers and USSD Codes
- Activate the payment method

## Features

✅ Allow you to get mobile money directly on your mobile money number <br>
✅ The UI adapts to your woocommerce theme

## Screenshort
<img src="https://user-images.githubusercontent.com/6081388/205290433-76292a23-f07a-4a12-8411-e310467e55d3.png" width="350" />

## Contributors
<a href = "https://github.com/nehemiekoffi/woocommerce-mobile-money-plugin/contributors">
  <img src = "https://contrib.rocks/image?repo=nehemiekoffi/woocommerce-mobile-money-plugin"/>
</a>
